export class Quiz {
}
