import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quit',
  templateUrl: './quit.component.html',
  styleUrls: ['./quit.component.css']
})
export class QuitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
